import requests
from base64 import b64decode, b64encode, urlsafe_b64decode, urlsafe_b64encode

REMOTE = True
user_email = "aaaaaaaaaa" + 'admin\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b' + 'b'*15

s = requests.Session()
if REMOTE:
    r = s.post("https://cookiecutter.chal.cyberjousting.com/login", data={'email':user_email})
else:
    r = s.post("http://127.0.0.1:1337/login", data={'email':user_email})
cookie = r.cookies.get_dict()['cookie'].encode()

print(cookie)
cookie_info = b64decode(cookie)
blks = []
for i in range(0, len(cookie_info), 16):
    blks.append(cookie_info[i:i+16])
pload_cookie = b64encode(blks[0] + blks[3] + blks[1])
print(pload_cookie)

s = requests.Session()
if REMOTE:
    r = s.get("https://cookiecutter.chal.cyberjousting.com/authenticate", cookies = {'cookie': pload_cookie.decode()})
else:
    r = s.get("http://127.0.0.1:1337/authenticate", cookies = {'cookie': pload_cookie.decode()})
print(r.text)