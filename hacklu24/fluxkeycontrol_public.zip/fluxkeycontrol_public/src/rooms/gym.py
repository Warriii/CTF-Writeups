from const import FLAG

def gym_zone():
    print("Seems like someone played capture-the-flag here ...")
    print("                 ")
    print(f"  FLAG: {FLAG}  ")
    print("                 ")
    exit(0)
